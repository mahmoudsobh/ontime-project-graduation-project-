var file;
var userid;
;(function(){


  // Initialize Firebase
var config = {
    apiKey: "AIzaSyA6KB2jVMQN3bNO7G1UiXudp01dptSOtZ4",
    authDomain: "ontime-34e0d.firebaseapp.com",
    databaseURL: "https://ontime-34e0d.firebaseio.com",
    projectId: "ontime-34e0d",
    storageBucket: "ontime-34e0d.appspot.com",
    messagingSenderId: "1051844606542"
  };
  firebase.initializeApp(config);

  //get element
  const txtfname=document.getElementById('fname');
  const txtlname=document.getElementById('lname');
  const txtemail=document.getElementById('email');

  const txtnational=document.getElementById('national');
  const txtpass=document.getElementById('pass');


  const btnsignup=document.getElementById('signup');

  //add signup event
  btnsignup.addEventListener('click',e=>{
	  console.log("get in here");
	  const fname=txtfname.value;
	  const lname=txtlname.value;

	  var email = document.getElementById('e').value;
	  console.log("the email");
      var password = document.getElementById('pass').value;



	  const national=txtnational.value;
var ref = firebase.database().ref().child("users");


const promise=firebase.auth().createUserWithEmailAndPassword(email, password);
promise.catch(function(error) {
  // Handle Errors here.
  var errorCode = error.code;
  var errorMessage = error.message;
  if (errorCode == 'auth/weak-password') {
    alert('The password is too weak please enter a valid one.');
  }
else if (errorCode == 'auth/email-already-in-use') {
                alert('The email is already taken please enter a new one.');
            }
  else {
    alert(errorMessage);
  }
  console.log(error);
});
//to enter the wrist of the user data
promise.then(function(user){
	window.userid=firebase.auth().currentUser.uid;
	console.log('in the then func');
	//var firebase=firebase.firestore();
	//var ref=firestore.child("user");


	var data={

		First_Name:fname,
		Last_Name:lname,
		Email:email,

		Password:password,
		Nationa_ID:national,

	id:window.userid
	}
console.log(window.userid);
	ref.child(window.userid).set(data).then(function(ref){
console.log("saved the data ");


console.log(window.userid);
      var storageRef = firebase.storage().ref('images').child(window.userid);
console.log('fff');
      storageRef.put(file).then(function(ref){console.log('saved');
	   window.location = 'index.html';
	  }


     , function error(err) {
console.log(err);
console.log('error');
      }

 );



	}
	,function(error){
	console.log(error);});





	})





});
/*************************************************
for the image upload
*************************************************/

var fileButton = document.getElementById ('fileButton');

      fileButton.addEventListener('change', function (e){

         window.file = e.target.files[0];
		console.log(file);


      });
}());
