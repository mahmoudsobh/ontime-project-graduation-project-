;(function(){
	  // Initialize Firebase
var config = {
    apiKey: "AIzaSyA6KB2jVMQN3bNO7G1UiXudp01dptSOtZ4",
    authDomain: "ontime-34e0d.firebaseapp.com",
    databaseURL: "https://ontime-34e0d.firebaseio.com",
    projectId: "ontime-34e0d",
    storageBucket: "ontime-34e0d.appspot.com",
    messagingSenderId: "1051844606542"
  };

firebase.initializeApp(config);

// to get element
var name=document.getElementById("name");
var age=document.getElementById("age");
var livein=document.getElementById("livein");
var hobbies=document.getElementById("hobbies");
var nameaside=document.getElementById("nameaside");
var image=document.getElementById("image");
var phone_num=document.getElementById("phone_num");
var from_to=document.getElementById("from_to");
var trip_time=document.getElementById("trip_time");
var price=document.getElementById("price");
var car_type=document.getElementById("car_type");
var places=document.getElementById("places");
var constraint=document.getElementById("constraint");
var tel=document.getElementById("tel");
var email=document.getElementById("email");
/***************************************
the element of the contact user
*****************************************/
const txtname=document.getElementById('contactname');
const txtemail=document.getElementById('contactemail');
const txtmsg=document.getElementById('contactmessage');
/********************************************
the profile data
**********************************************/
// the id from selected div in the private page
id = localStorage["id"];
console.log(id);

//to retrieve the make offer data to be placed in the html
var getdata=firebase.database().ref('make_offer/'+id+'2');
getdata.on('value',function(datasnapshot){
from_to.innerHTML=' From : '+datasnapshot.val().From+' To : '+datasnapshot.val().To;
trip_time.innerHTML='at:'+datasnapshot.val().Trip_Time;
price.innerHTML='Price:'+datasnapshot.val().Price;
car_type.innerHTML='Car_Type:'+datasnapshot.val().Car_Type;
places.innerHTML='Avaliable_Places:'+datasnapshot.val().Avaliable_Places;
constraint.innerHTML=datasnapshot.val().Constraint;
});

//to retrieve the user data to be placed in the html
var getdata=firebase.database().ref("users/"+id);
getdata.on('value',function(datasnapshot){
name.innerHTML=datasnapshot.val().First_Name+' '+datasnapshot.val().Last_Name;
//nameaside.innerHTML=datasnapshot.val().First_Name+' '+datasnapshot.val().Last_Name;
email.innerHTML=datasnapshot.val().Email;
console.log(datasnapshot.val().First_Name);
console.log(datasnapshot.val().Email);
console.log(datasnapshot.val().Last_Name);
});

// to retriev the photo to be placed in the html
var jj=firebase.storage().ref("images/"+id).getDownloadURL().then(function(url) {
var test = url;
document.getElementById('image').src = url;
}).catch(function(error) {
console.log('error');
});

//to retrieve the userprofile data to be placed in the html
var data="profile"+id;
var getdata=firebase.database().ref("users/"+data);
getdata.on('value',function(datasnapshot){
age.innerHTML=datasnapshot.val().age;
livein.innerHTML=datasnapshot.val().live_in;
hobbies.innerHTML=datasnapshot.val().hobbies;
phone_num.innerHTML=datasnapshot.val().phone_num;
tel.innerHTML=datasnapshot.val().phone_num;
});
/********************************************
the contact us data
**********************************************/
sendmsg.addEventListener('click',e=>{
console.log("get in here");
const name=txtname.value;
const email=txtemail.value;
console.log(email);
const msg=txtmsg.value;
var ref = firebase.database().ref().child("contact_us");
var data={
name:name,
email:email,
message:msg
}
ref.child(name).set(data).then(function(ref){
console.log("saved the data ");
}
,function(error){
console.log(error);});
});


 }());