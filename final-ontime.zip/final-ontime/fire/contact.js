;(function(){
  // Initialize Firebase
var config = {
    apiKey: "AIzaSyA6KB2jVMQN3bNO7G1UiXudp01dptSOtZ4",
    authDomain: "ontime-34e0d.firebaseapp.com",
    databaseURL: "https://ontime-34e0d.firebaseio.com",
    projectId: "ontime-34e0d",
    storageBucket: "ontime-34e0d.appspot.com",
    messagingSenderId: "1051844606542"
  };
  firebase.initializeApp(config);

  const txtname=document.getElementById('name');
  const txtemail=document.getElementById('email');


  const txtmsg=document.getElementById('message');
  console.log('ohhhh ');

  sendmsg.addEventListener('click',e=>{
	  console.log("get in here");
	  const name=txtname.value;
	  const email=txtemail.value;

  const msg=txtmsg.value;
  var ref = firebase.database().ref().child("contact_us");

	var data={
		name:name,
		email:email,

		message:msg

	}

	ref.child(name).set(data).then(function(ref){
console.log("saved the data ");

	}
	,function(error){
	console.log(error);});
  });
  }());