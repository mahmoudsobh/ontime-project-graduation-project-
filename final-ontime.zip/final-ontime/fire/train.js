;(function(){


  // Initialize Firebase
var config = {
    apiKey: "AIzaSyA6KB2jVMQN3bNO7G1UiXudp01dptSOtZ4",
    authDomain: "ontime-34e0d.firebaseapp.com",
    databaseURL: "https://ontime-34e0d.firebaseio.com",
    projectId: "ontime-34e0d",
    storageBucket: "ontime-34e0d.appspot.com",
    messagingSenderId: "1051844606542"
  };
  firebase.initializeApp(config);

  //get element
  const txttrainstops=document.getElementById('time');


  function show_selected() {
 const listto=document.getElementById('to');
 var tovalue=listto.options[listto.selectedIndex].text;
console.log(tovalue);
	const listfrom=document.getElementById('from');
var fromvalue=listfrom.options[listfrom.selectedIndex].text;
	console.log(fromvalue);

if(tovalue=="القاهرة" && fromvalue=="السويس" ){
	console.log('lalal');
	//to get the data
	var getdata=firebase.database().ref("suezcairo/");
	getdata.on("child_added",function(data,prevChildKey){
		var newrow=data.val();


		txttrainstops.innerHTML=newrow.zerorow;
		var Str=txttrainstops.innerHTML.replace(/,/g,"<br>");
		document.getElementById("time").innerHTML = Str;

	});


}
else if(tovalue=="القاهرة" && fromvalue=="الاسكندريه" ){
	console.log('l');
	//to get the data
	var getdata=firebase.database().ref("alex-cairo");
	getdata.on("child_added",function(data,prevChildKey){
		var newrow=data.val();

		txttrainstops.innerHTML=newrow.zerorow;
		var Str=txttrainstops.innerHTML.replace(/,/g,"<br>");
		document.getElementById("time").innerHTML = Str;

	});


}


else if(tovalue=="القاهرة" && fromvalue=="مرسي مطروح" ){
	console.log('l');
	//to get the data
	var getdata=firebase.database().ref("matrohcairo/");
	getdata.on("child_added",function(data,prevChildKey){
		var newrow=data.val();

		txttrainstops.innerHTML=newrow.zerorow;
		var Str=txttrainstops.innerHTML.replace(/,/g,"<br>");
		document.getElementById("time").innerHTML = Str;

	});


}


else if(tovalue=="القاهرة" && fromvalue=="دمياط" ){
	console.log('l');
	//to get the data
	var getdata=firebase.database().ref("domyat-cairo/");
	getdata.on("child_added",function(data,prevChildKey){
		var newrow=data.val();

		txttrainstops.innerHTML=newrow.zerorow;
		var Str=txttrainstops.innerHTML.replace(/,/g,"<br>");
		document.getElementById("time").innerHTML = Str;

	});


}
else if(tovalue=="مرسي مطروح" && fromvalue=="القاهرة" ){
	console.log('l');
	//to get the data
	var getdata=firebase.database().ref("cairo-matroh/");
	getdata.on("child_added",function(data,prevChildKey){
		var newrow=data.val();

		txttrainstops.innerHTML=newrow.zerorow;
		var Str=txttrainstops.innerHTML.replace(/,/g,"<br>");
		document.getElementById("time").innerHTML = Str;

	});


}

else{

	txttrainstops.innerHTML=".لا يوجد قطارات لهذه الوجه ...نعتذر";

}
  }
	 document.getElementById('search').addEventListener('click', show_selected);


/*
var ref = firebase.database().ref().child("cairo-matroh");

	var data={

zerorow:{
	1:"نوعه:مميز",
	2:"القطار:قطار1205",
	3:"15محطات:القاهره,بنها,قويسنا,بركه السبع,طنطا,دمنهور,محرم بيك,العامريه,برج العرب,الحمام,العلمين,سيدي عبد الرحمن,الضبعه,مرسي مطروح",
	4:"يصل القاهره:5:40 صباحاً",
	5:"يصل مرسى مطروح:1:40 مساءً",
	6:"ــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ",
	7:"نوعه:مميز",
	8:" القطار:قطار939",
	9:"11محطات:القاهره,بنها,طنطا,دمنهور.محرم بيك,برج العرب.الحمام.العلمين,سيدي عبد الرحمن,الضبعه,مرسي مطروح",
	10:"يصل القاهره:1:30 مساءً",
	11:"يصل مرسي مطروح:5:45 صباحاً",
	12:"ــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ",
	13:"نوعه:قطار نوم",
	14:"القطار:قطار773",
	15:"4محطات:القاهره,طنطا,محرم بيك ,مرسي مطروح",
	16:"يصل القاهره:6:30 صباحاً",
	17:"يصل مرسي مطروح:11:30 مساءً"


	}}
	ref.child("cairo-matroh").set(data).then(function(ref){
console.log("saved the data ");

	}
	,function(error){
	console.log(error);});
*/
//********************************************************

}());
