var get=0;
;(function(){


  // Initialize Firebase
var config = {
    apiKey: "AIzaSyA6KB2jVMQN3bNO7G1UiXudp01dptSOtZ4",
    authDomain: "ontime-34e0d.firebaseapp.com",
    databaseURL: "https://ontime-34e0d.firebaseio.com",
    projectId: "ontime-34e0d",
    storageBucket: "ontime-34e0d.appspot.com",
    messagingSenderId: "1051844606542"
  };
  firebase.initializeApp(config);
  //add signup event
 btnlogin.addEventListener('click',e=>{
	  console.log("get in here");
	   var email = document.getElementById('email').value;
	  console.log("the email");
      var password = document.getElementById('pass').value;
	 const promise=  firebase.auth().signInWithEmailAndPassword(email, password);

promise.catch(function(error) {

          // Handle Errors here.
          var errorCode = error.code;
          var errorMessage = error.message;
          // [START_EXCLUDE]
          if (errorCode === 'auth/wrong-password') {
            alert('Wrong password.');
			get=1;
          } else {
            alert(errorMessage);
          }

	   });
	promise.then((firebaseUser) => {
        return firebaseUser
    })
    .then((firebaseUser) => {
      firebase.auth().onAuthStateChanged(function(firebaseUser) {
        if (firebaseUser) {
          window.location = 'index.html'
        }
      });
    })




  });
})();