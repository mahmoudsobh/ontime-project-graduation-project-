var currentuser;
var count=1;
;(function(){
	  // Initialize Firebase
var config = {
    apiKey: "AIzaSyA6KB2jVMQN3bNO7G1UiXudp01dptSOtZ4",
    authDomain: "ontime-34e0d.firebaseapp.com",
    databaseURL: "https://ontime-34e0d.firebaseio.com",
    projectId: "ontime-34e0d",
    storageBucket: "ontime-34e0d.appspot.com",
    messagingSenderId: "1051844606542"
  };
  firebase.initializeApp(config);
  /* --------------------------------------------------------
  // get what selected in the search area
  ----------------------------------------------------*/
  search.addEventListener("click",e=>{
const listfrom=document.getElementById('from');
 var fromvalue=listfrom.options[listfrom.selectedIndex].text;
console.log(fromvalue);
localStorage["from"] =fromvalue;

   const listto=document.getElementById('to');
 var tovalue=listto.options[listto.selectedIndex].text;
console.log(tovalue);
localStorage["to"] =tovalue;
  });
  /* --------------------------------------------------------
  // make an offer
  ----------------------------------------------------*/
   //get element
console.log('jjjjjjjjjjjjjj');
const txt1=document.getElementById('1');
  const txt2=document.getElementById('2');
  const txt3=document.getElementById('3');
const txt4=document.getElementById('4');
  const txt5=document.getElementById('5');
  const txt6=document.getElementById('6');
  const txt7=document.getElementById('7');
  const txt8=document.getElementById('8');
  const txt9=document.getElementById('9');
  const txt10=document.getElementById('10');
  const txt11=document.getElementById('11');
  console.log('ohhhh ');
/*********************************************
to get the current user and place his data
*********************************************/
var currentUser;
firebase.auth().onAuthStateChanged(function(user) {
	console.log('lala');
  if (user) {
     window.currentuser = user.uid;
	 console.log('the id         '+window.currentuser );
	  console.log('here');
      console.log(window.currentuser); //this returns my user object
      window.localStorage.setItem("UID",currentUser);
	  	//to get the data from the user profile
		var cat="profile"+window.currentuser;
		var data="user"+cat;
		console.log(data);
	var getdata=firebase.database().ref("user/"+cat);
	console.log(getdata);

	console.log('hgyfy');
	var save="profile"+window.currentuser;
	console.log("save="+save);

var getdata=firebase.database().ref("users/"+save);
	getdata.on('value',function(datasnapshot){
		txt6.innerHTML=datasnapshot.val().age;
		console.log(datasnapshot.val().age);
		txt7.innerHTML=datasnapshot.val().live_in;
		console.log(datasnapshot.val().live_in);
		txt8.innerHTML=datasnapshot.val().hobbies;
		console.log(datasnapshot.val().hobbies);
		txt9.innerHTML=datasnapshot.val().phone_num;
		console.log(datasnapshot.val().phone_num);

 });




  } else {
      currentUser = "Error"
      console.log(currentUser); //this returns my user object
      window.localStorage.setItem("UID",currentUser);
       alert(" Error in your login code");
    // No user is signed in.
  }
});

  send.addEventListener('click',e=>{
	  console.log("get in here");
	  const t1=txt1.value;
	  const t2=txt2.value;
 const t3=txt3.value;
 const t4=txt4.value;
 const t5=txt5.value;
 const t6=txt6.value;
 const t7=txt7.value;
 const t8=txt8.value;
 const t9=txt9.value;
 const t10=txt10.value;
 const t11=txt11.value;
  var ref = firebase.database().ref().child("make_offer");
var userref = firebase.database().ref().child("users");
	var data={
		From:t10,
		To:t11,
		Trip_Time:t1,
		Price:t2,
		Avaliable_Places:t3,
		Car_Type:t4,
Constraint:t5,
id:window.currentuser
	}
	window.count+=1;
	var userdata={
		age:t6,
live_in:t7,
hobbies:t8,
phone_num:t9
	}
	//to get the next offer window count
const val=window.currentuser+window.count;
console.log(val);
	ref.child(val).set(data).then(function(ref){
console.log("saved the data ");
var modal = document.getElementById('myModaloffer');
 modal.style.display = "none";
	}
	,function(error){
	console.log(error);});
	/**********************************************
	the profile data
	**********************************************/
	var se="profile"+window.currentuser;
	var ref = firebase.database().ref("users/"+se);
ref.once("value").then(function(snapshot) {
console.log("ssss="+se);

	  if (snapshot.exists()) {
	  console.log('exists');
	  //to update if exists
	  firebase.database().ref("users/"+se)
        .update({ age:t6,live_in:t7,
hobbies:t8,
phone_num:t9 });
    // update
  } else {
    // create new nationality
	console.log('not exists');
	//to create if not exists
		var save="profile"+window.currentuser;
		userref.child(save).set(userdata).then(function(ref){
console.log("saved the user data ");

	}
	,function(error){
	console.log(error);});
  }

  });


  });



  /* ---------------------------------------------------------
  //end make offer scripts
  ------------------------------------------------------------*/
}());