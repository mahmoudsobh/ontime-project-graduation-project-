window.num=0;
;(function(){
	  // Initialize Firebase
var config = {
    apiKey: "AIzaSyA6KB2jVMQN3bNO7G1UiXudp01dptSOtZ4",
    authDomain: "ontime-34e0d.firebaseapp.com",
    databaseURL: "https://ontime-34e0d.firebaseio.com",
    projectId: "ontime-34e0d",
    storageBucket: "ontime-34e0d.appspot.com",
    messagingSenderId: "1051844606542"
  };

firebase.initializeApp(config);


  /****************************************
  to get the count of document in collection
  ****************************************/
var a=0;
firebase.database().ref('make_offer').once("value", function(snapshot) {
   a = snapshot.numChildren();
  console.log(a);
});






  //get element
  const txtimg=document.getElementById('img');
  const txtname=document.getElementById('name');
  const txtdate=document.getElementById('date');
  const txtdest=document.getElementById('dest');

  /****************************************
  to get the data
  ****************************************/
  var getdata=firebase.database().ref('make_offer');
	getdata.on('value',function(datasnapshot){
		console.log(datasnapshot.val());


 });

 var ref = firebase.database().ref('make_offer').orderByKey();
window.intVal=[];

window.intNum=[];
ref.once("value", function(snapshot) {
	console.log("hhhfh"+snapshot);
	console.log(snapshot);
 snapshot.forEach(function(childSnapshot) {
  var childData = childSnapshot.val();
  var id=childData.id;
  console.log(childData);
  console.log(childSnapshot.val().id);
window.intVal.push(childSnapshot.val().id);
    console.log("intVal",this.intVal);







  //to retrieve the user data to be placed in the html
  var getdata=firebase.database().ref("users/"+id);
	getdata.on('value',function(datasnapshot){
		//txtname.innerHTML=datasnapshot.val().First_Name+' '+datasnapshot.val().Last_Name;
		$("#namediv").append("<div><h5 style='height:70px;width:190px;text-align:center;'>"+datasnapshot.val().First_Name+' '+datasnapshot.val().Last_Name+"<h5></div>");

$("#namediv").append('<br/>'+'<br/>'+'<br/>');

$("#name").on('click',function(){
   console.log (document.getElementById("name").textContent);
});

console.log(datasnapshot.val().First_Name);
console.log(datasnapshot.val().Last_Name);
	});

    //to retrieve the make offer data to be placed in the html
  var getdata=firebase.database().ref('make_offer/'+id+'2');
	getdata.on('value',function(datasnapshot){
		//txtdest.innerHTML=' from : '+datasnapshot.val().From+' to : '+datasnapshot.val().To;
		//txtdate.innerHTML='at:'+datasnapshot.val().Trip_Time;
		$("#dest").append("<div><h5    style='height:70px;width:190px;text-align:center;'>"+' from : '+datasnapshot.val().From+' to : '+datasnapshot.val().To+"<h5></div>");
		$("#date").append("<div><h5   style='height:70px;width:190px;text-align:center;' >"+'at:'+datasnapshot.val().Trip_Time+"<h5></div>");
$("#dest").append('<br/>'+'<br/>'+'<br/>');
$("#date").append('<br/>'+'<br/>'+'<br/>');
	});


  // to retriev the photo to be placed in the html

console.log('images/'+id);

window.intImg=[];
 var jj=firebase.storage().ref('images/'+id).getDownloadURL().then(function(url) {
	console.log('in the then func');
	var test = url;


 //  var img = document.createElement("img");
//img.height=70;
//img.width=100;
//img.src = url;
window.intImg.push(url);
//var src = document.getElementById("i");

//src.appendChild(img );
var newimg = document.createElement("img");
newimg.setAttribute("src", url);
newimg.setAttribute("id", "img");
newimg.setAttribute("alt", window.num);
newimg.setAttribute("style", "height:80px; width:100px; ");
window.num+=1;
newimg.onclick = function () {
    console.log(newimg.alt);
	 console.log(newimg.src);
	 console.log(newimg.alt+"the id "+intVal[newimg.alt]);
	 localStorage["id"]=intVal[newimg.alt];
 location.href ='profile.html';
};
$("#i").append(newimg);
$("#i").append('<br/>'+'<br/>'+'<br/>');






 }
).catch(function(error) {


	console.log('error');
});



	});



});




 }());