;(function(){
	  // Initialize Firebase
var config = {
    apiKey: "AIzaSyA6KB2jVMQN3bNO7G1UiXudp01dptSOtZ4",
    authDomain: "ontime-34e0d.firebaseapp.com",
    databaseURL: "https://ontime-34e0d.firebaseio.com",
    projectId: "ontime-34e0d",
    storageBucket: "ontime-34e0d.appspot.com",
    messagingSenderId: "1051844606542"
  };

firebase.initializeApp(config);


  console.log(localStorage["from"] );
  console.log(localStorage["to"] );

  var tovalue=localStorage["to"] ;
  var fromvalue=localStorage["from"];
if(tovalue=='cairo'&&fromvalue=="alexandria"){


//the train part

$("#from").append(fromvalue+'<br/>'+'<br/>'+'<br/>');
$("#to").append(tovalue+'<br/>'+'<br/>'+'<br/>');
$("#i").append(" <img src='https://img.icons8.com/ios/50/000000/train-filled.png' style='padding: 10px;'>");
$("#i").append('<br/>'+'<br/>'+'<br/>');
$("#dest").append("<a href='https://enr.gov.eg/ticketing/public/smartSearch.jsf'><button class='btn-danger' style='margin-left: 20px; border-radius: 5px; margin-top: 25px;'>Booking</button></a>");
$("#btn").append("<a href='train.html'><button class='btn-info' style='margin-left: 20px; border-radius: 5px; margin-top: 25px;'>Check All Schdeule </button></a>");
$("#dest").append('<br/>'+'<br/>'+'<br/>');
$("#btn").append('<br/>'+'<br/>'+'<br/>');
}
else if(tovalue=='cairo'&&fromvalue=="suez"){


//the train part

$("#from").append(fromvalue+'<br/>'+'<br/>'+'<br/>');
$("#to").append(tovalue+'<br/>'+'<br/>'+'<br/>');
$("#i").append(" <img src='https://img.icons8.com/ios/50/000000/train-filled.png' style='padding: 10px;'>");
$("#i").append('<br/>'+'<br/>'+'<br/>');
$("#dest").append("<a href='https://enr.gov.eg/ticketing/public/smartSearch.jsf'><button class='btn-danger' style='margin-left: 20px; border-radius: 5px; margin-top: 25px;'>Booking</button></a>");
$("#btn").append("<a href='train.html'><button class='btn-info' style='margin-left: 20px; border-radius: 5px; margin-top: 25px;'>Check All Schdeule </button></a>");
$("#dest").append('<br/>'+'<br/>'+'<br/>');
$("#btn").append('<br/>'+'<br/>'+'<br/>');
}
else if(tovalue=='cairo'&&fromvalue=="marsa matrouh"){


//the train part

$("#from").append(fromvalue+'<br/>'+'<br/>'+'<br/>');
$("#to").append(tovalue+'<br/>'+'<br/>'+'<br/>');
$("#i").append(" <img src='https://img.icons8.com/ios/50/000000/train-filled.png' style='padding: 10px;'>");
$("#i").append('<br/>'+'<br/>'+'<br/>');
$("#dest").append("<a href='https://enr.gov.eg/ticketing/public/smartSearch.jsf'><button class='btn-danger' style='margin-left: 20px; border-radius: 5px; margin-top: 25px;'>Booking</button></a>");
$("#btn").append("<a href='train.html'><button class='btn-info' style='margin-left: 20px; border-radius: 5px; margin-top: 25px;'>Check All Schdeule </button></a>");
$("#dest").append('<br/>'+'<br/>'+'<br/>');
$("#btn").append('<br/>'+'<br/>'+'<br/>');
}

else if(tovalue=='cairo'&&fromvalue=="damietta"){


//the train part

$("#from").append(fromvalue+'<br/>'+'<br/>'+'<br/>');
$("#to").append(tovalue+'<br/>'+'<br/>'+'<br/>');
$("#i").append(" <img src='https://img.icons8.com/ios/50/000000/train-filled.png' style='padding: 10px;'>");
$("#i").append('<br/>'+'<br/>'+'<br/>');
$("#dest").append("<a href='https://enr.gov.eg/ticketing/public/smartSearch.jsf'><button class='btn-danger' style='margin-left: 20px; border-radius: 5px; margin-top: 25px;'>Booking</button></a>");
$("#btn").append("<a href='train.html'><button class='btn-info' style='margin-left: 20px; border-radius: 5px; margin-top: 25px;'>Check All Schdeule </button></a>");
$("#dest").append('<br/>'+'<br/>'+'<br/>');
$("#btn").append('<br/>'+'<br/>'+'<br/>');
}
else if(fromvalue=='cairo'&&tovalue=="damietta"){


//the train part

$("#from").append(fromvalue+'<br/>'+'<br/>'+'<br/>');
$("#to").append(tovalue+'<br/>'+'<br/>'+'<br/>');
$("#i").append(" <img src='https://img.icons8.com/ios/50/000000/train-filled.png' style='padding: 10px;'>");
$("#i").append('<br/>'+'<br/>'+'<br/>');
$("#dest").append("<a href='https://enr.gov.eg/ticketing/public/smartSearch.jsf'><button class='btn-danger' style='margin-left: 20px; border-radius: 5px; margin-top: 25px;'>Booking</button></a>");
$("#btn").append("<a href='train.html'><button class='btn-info' style='margin-left: 20px; border-radius: 5px; margin-top: 25px;'>Check All Schdeule </button></a>");
$("#dest").append('<br/>'+'<br/>'+'<br/>');
$("#btn").append('<br/>'+'<br/>'+'<br/>');
}

else{
$("#from").append('Sorry no train available'+'<br/>'+'<br/>'+'<br/>');
$("#to").append('check for other available'+'<br/>'+'<br/>'+'<br/>');
$("#i").append(" <img src='https://img.icons8.com/ios/50/000000/train-filled.png' style='padding: 10px;'>");
$("#i").append('<br/>'+'<br/>'+'<br/>');
$("#dest").append("<a href='https://enr.gov.eg/ticketing/public/smartSearch.jsf'><button class='btn-danger' style='margin-left: 20px; border-radius: 5px; margin-top: 25px;'>railway booking</button></a>");
$("#btn").append("<a href='train.html'><button class='btn-info' style='margin-left: 20px; border-radius: 5px; margin-top: 25px;'>Check for other Schdeules </button></a>");
$("#dest").append('<br/>'+'<br/>'+'<br/>');
$("#btn").append('<br/>'+'<br/>'+'<br/>');

}




//the car part



var ref = firebase.database().ref('make_offer').orderByKey();

ref.on("value", function(snapshot) {

 snapshot.forEach(function(childSnapshot) {
  var childData = childSnapshot.val();
  var id=childData.id;

  //to retrieve the user data to be placed in the html
  var getdata=firebase.database().ref("make_offer/"+id+'2');
	getdata.on('value',function(datasnapshot){

		//txtname.innerHTML=datasnapshot.val().First_Name+' '+datasnapshot.val().Last_Name;
		console.log(datasnapshot.val().To);
		console.log(datasnapshot.val().From);
		console.log('----------------------------');
		console.log(tovalue);
		console.log(fromvalue);
		console.log('----------------------------');


		if(tovalue==datasnapshot.val().To && fromvalue==datasnapshot.val().From){
console.log('get in here');
			$("#from").append(fromvalue+'<br/>'+'<br/>'+'<br/>');
$("#to").append(tovalue+'<br/>'+'<br/>'+'<br/>');
$("#i").append(" <img src='https://img.icons8.com/ios/50/000000/fiat-500-filled.png' style='padding: 10px;'>");
$("#i").append('<br/>'+'<br/>'+'<br/>');
localStorage["id"] =childSnapshot.val().id;
$("#dest").append("<a href='profile.html'><button class='btn-danger' style='margin-left: 20px; border-radius: 5px; margin-top: 25px;'>Booking</button></a>");
$("#dest").append('<br/>'+'<br/>'+'<br/>');
$("#btn").append("<a href='priv.html'><button class='btn-info' style='margin-left: 20px; border-radius: 5px; margin-top: 25px;'>Know About All </button></a>");
$("#btn").append('<br/>'+'<br/>'+'<br/>');


		};





	});
});
 });

 }());