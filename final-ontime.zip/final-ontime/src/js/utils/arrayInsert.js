export const arrayInsert = (arr, index, item) => arr.splice(index, 0, item);
