export const isNull = value => value === null;
