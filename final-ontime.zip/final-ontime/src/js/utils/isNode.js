export const isNode = value => value instanceof HTMLElement;
